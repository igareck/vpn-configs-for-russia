---
## 🌏 Бесплатные VPN-конфигурации, работающие в РФ 
---

📚 Коллекция реально работающих на территории Российской Федерации публичных VPN-конфигураций (`VLESS+Reality` / `VMess` / `Hysteria2` / `Tuic`/ `Shadowsocks` / `Trojan`  и прочее) для обхода блокировок РКН.

Каждая конфигурация — это TXT-подписка, которую можно импортировать в большинство современных клиентов (`v2rayN`, `V2Box`, `v2RayTun`, `Hiddify` и прочее).

Перед опубликованием конфиги всегда проходят тесты на скорость/задержку на кабельном/мобильном интернете на сервере в РФ, медленные и неработающие отсеиваются. 


## 📑 Это просто коллекция публичных VPN? ☝️ Не совсем!
Это не просто коллекция бесплатных, собранных со всего интернета конфигов VPN. 

**Это отфильтрованная коллекция того, что работает именно в Российских сетях.**

Обычные VPN не работают уже давно, и не влияет - платная у вас подписка или нет. 

Поэтому важно использовать конфигурации, проверенные в работе именно в России, чтобы всегда оставаться онлайн.

В самом начале из 40.000+ взятых на пробу бесплатных публичных конфигураций - проверку на работоспособность прошли примерно 700 штук, а это всего около 2%, а в итоге тут выложил около 200 самых качественных с высоким откликом и приличной скоростью. 

Конфигураций под белые списки Роскомнадзора, понятно, что меньше от общего числа. 

Протоколов в сети целый вагон, но **самый эффективный**, защищающий от DPI Роскомнадзора и его блокировок - это **Vless+Reality** из-за способности маскировать трафик под безобидный HTTPS сайт, делая использование VPN абсолютно невидимым для вашего интернет-провайдера. Остальные протоколы - идут по убывающей в рейтинге, так как легче демаскируются.  

Поэтому на Vless+Reality буду делать основной упор и выкладывать в первую очередь его, а остальное - по мере необходимости.
Я вообще думаю, что нет особого смысла работать с протоколами, уходящими в прошлое, рядового пользователя это огромное количество только путает.

⚡ Часть конфигураций со временем могут перестать работать от независящих от меня причин, поэтому списки будут периодически обновляться.
Выкладываю впервые, пока разобрал, на что хватило времени, потом буду выкладывать больше.

⚡ Если конфигурация вдруг перестала работать - не спешите ее удалять, просто переключитесь на следующую в списке, она через некоторое время, возможно, оживет. Но это неточно! Просто такая особенность, это нормально!

## В чем разница между черными и белыми списками и какую подписку выбрать❓
**Черные списки** - это когда "разрешено все, что не запрещено". *Это обычная работа интернета в 90% случаев*.

**Белые списки** - это когда "запрещено все, что не разрешено". Это когда у вас не получается никуда зайти кроме Яндекса и подобных сайтов в принципе, даже Google не откроется.

*Интернет при белых списках - самый ограниченный. Вы сможете зайти только туда, куда одобрит регулятор, используя свои "белые" списки. То есть, например, Роскомнадзор одобрил только Яндекс и Озон - вы сможете зайти только на Яндекс и Озон и никуда кроме. Эти ограничения сейчас массово тестируются и применяются на практике мобильными провайдерами.*

🔻🔻🔻

**1)** **Выбираем сначала черное или белое** ⚫⚪: в стандартной ситуации, когда интернет работает как обычно, открывается Google, но захотели посмотреть заблокированный Youtube - используем конфигурации из черных списков. Когда ограничен - из белых;

**2)** **Выбираем платформу: кабельный или мобильный интернет** (обычно то, что работает на кабеле - не всегда работает в мобильном интернете и наоборот, но ради интереса можете миксовать);

**3)** **Выбираем** самый устойчивый протокол **Vless+Reality**, а **Shadowsocks/Hysteria2** используем как альтернативу. 

*Уточню, что Hysteria2 у меня прекрасно работает на ПК через кабель, но на смартфоне через Wifi отказывается, почему - пока не выяснил. Vless и Shadowsocks работают на любых устройствах без проблем.*

## 🖥️ Как мне воспользоваться этими конфигурациями у себя на устройстве 
VPN-конфигурации на вашем устройстве удобнее всего добавлять через *"подписку"* или *"группу подписки"*, копируя url-адрес txt-файла Github из следующего пункта. 

Для удобства добавил QR-коды.

Можно, конечно, добавлять ссылки вручную по-отдельности, просто копируя их, но подписки удобнее тем, что они обновляются автоматически у вас на устройстве после обновления на Github, без необходимости удаления и нового копирования, упрощая процесс.

## 📑 Конфигурации VPN и подписки

<details>

<summary>📋 ЧЕРНЫЙ СПИСОК ⚫</summary>

---

> **Протестировано на кабельном провайдере**:

**Vless+Reality** [Vless-Reality-Black-Lists-Rus-Cable.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/Vless-Reality-Black-Lists-Rus-Cable.txt)

<details>
<summary> QR-код </summary>

  ![Vless-Reality-Black-Lists-Rus-Cable-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/Vless-Reality-Black-Lists-Rus-Cable-QR.png)

</details>

**Shadowsocks/Hysteria2** [Shadowsocks-Hysteria2-Black-Lists-Rus-Cable.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/Shadowsocks-Hysteria2-Black-Lists-Rus-Cable.txt)

<details>
<summary> QR-код </summary>

  ![Shadowsocks-Hysteria2-Black-Lists-Rus-Cable-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/Shadowsocks-Hysteria2-Black-Lists-Rus-Cable-QR.png)

</details>

---

> **Протестировано на  мобильном операторе** :

**Vless+Reality** [Vless-Reality-Black-Lists-Rus-Mobile.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/Vless-Reality-Black-Lists-Rus-Mobile.txt)

<details>
<summary> QR-код </summary>

  ![Vless-Reality-Black-Lists-Rus-Mobile-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/Vless-Reality-Black-Lists-Rus-Mobile-QR.png)

</details>

**Shadowsocks/Hysteria2** [Shadowsocks-Hysteria2-Black-Lists-Rus-Mobile.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/Shadowsocks-Hysteria2-Black-Lists-Rus-Mobile.txt)

<details>
<summary> QR-код </summary>

  ![Shadowsocks-Hysteria2-Black-Lists-Rus-Mobile-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/Shadowsocks-Hysteria2-Black-Lists-Rus-Mobile-QR.png)

</details>

</details>

---

<details>

<summary>📋 БЕЛЫЙ СПИСОК ⚪</summary>
.

> **Протестировано на кабельном провайдере**:  [Vless-Reality-White-Lists-Rus-Cable.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/Vless-Reality-White-Lists-Rus-Cable.txt)

<details>
<summary> QR-код </summary>

  ![Vless-Reality-White-Lists-Rus-Cable-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/Vless-Reality-White-Lists-Rus-Cable-QR.png)

</details>

> **Протестировано на мобильном операторе** :  [Vless-Reality-White-Lists-Rus-Mobile.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/Vless-Reality-White-Lists-Rus-Mobile.txt)

<details>
<summary> QR-код </summary>

  ![Vless-Reality-White-Lists-Rus-Mobile-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/Vless-Reality-White-Lists-Rus-Mobile-QR.png)

</details>

> **Полный список (даже с конфигурациями, не прошедшими проверку)**:  [White_Lists_Full_Rus.txt](https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/White_Lists_Full_Rus.txt)

<details>
<summary> QR-код </summary>

  ![White_Lists_Full_Rus-QR](https://github.com/igareck/vpn-configs-for-russia/blob/main/QR-codes/White_Lists_Full_Rus-QR.png)

</details>

</details>

## Приложения на ПК и телефоне: 
- **💻 Windows/Linux/MacOS** - установите официальный клиент v2rayN или Throne (бывш.Nekoray), добавьте конфиг/подписку, обновите ее, из появившегося списка выберите один из серверов начиная сверху-вниз, в конце запустите "Режим VPN/Режим TUN".

1) v2rayN: https://github.com/2dust/v2rayN/releases
  
   `v2rayN-windows-64.zip` для Windows
  
   `v2rayN-linux-64.deb` для Linux (Ubuntu)
  
   `v2rayN-macos-64.dmg` для MacOS

2) Throne (бывш.Nekoray): https://github.com/throneproj/Throne/releases

   `Throne-1.0.8-windows64-installer.exe` для Windows
  
   `Throne-1.0.8-debian-x64.deb` для Linux (Ubuntu)
  
   `Throne-1.0.8-macos-arm64.zip` для MacOS

- **📱 iOS** - используйте Streisand или v2RayTun из App Store.

  https://apps.apple.com/us/app/streisand/id6450534064
  
- **📱 Android** - используйте v2RayTun из Google Play.

  https://play.google.com/store/apps/details?id=com.v2raytun.android&hl=en&pli=1

# 🔖 Лицензия

Лицензия GPL-3.0. С лицензией можно ознакомиться в файле [`LICENSE`](LICENSE)

# Всем удачи и будьте всегда на связи!

*Данный пост не является рекламой VPN и не поощряет его использование. Представлен исключительно для ознакомления и в исследовательских/научных целях.* 

*Используйте VPN и любые средства обхода блокировок ответственно!*

# 👀 Количество посетителей
<img src="https://komarev.com/ghpvc/?username=igareck&label=Visitors&color=0e75b6&style=flat-square" alt="Visitor Count" /> <br/> <img src="https://visitor-badge.laobi.icu/badge?page_id=igareck.visitor-badge&left_color=black&right_color=green&left_text=Cyber+Hits" alt="Cyber Hits"/>  
</div>



